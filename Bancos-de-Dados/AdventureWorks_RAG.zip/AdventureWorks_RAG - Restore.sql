use master
go

ALTER DATABASE AdventureWorks_RAG SET SINGLE_USER WITH ROLLBACK IMMEDIATE
go
RESTORE DATABASE AdventureWorks_RAG FROM DISK = 'E:\_HandsOn_IAExpert\AdventureWorks_RAG_Inicial.bak' WITH recovery, replace, stats=5, 
MOVE 'AdventureWorks_RAG' TO 'E:\MSSQL_Data\AdventureWorks_RAG.mdf',
MOVE 'AdventureWorks_RAG_log' TO 'F:\MSSQL_Data\AdventureWorks_RAG_log.ldf'


ALTER AUTHORIZATION ON DATABASE::AdventureWorks_RAG TO sa


