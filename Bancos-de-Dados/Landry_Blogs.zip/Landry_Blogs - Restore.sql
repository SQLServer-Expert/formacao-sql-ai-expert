use master
go

ALTER DATABASE Landry_Blogs SET SINGLE_USER WITH ROLLBACK IMMEDIATE
go
RESTORE DATABASE Landry_Blogs FROM DISK = 'C:\Backup\Landry_Blogs.bak' WITH recovery, stats=5,
MOVE 'Landry_Blogs' TO 'C:\MSSQL_Data\Landry_Blogs.mdf',
MOVE 'Landry_Blogs_log' TO 'C:\MSSQL_Data\Landry_Blogs_log.ldf'


ALTER AUTHORIZATION ON DATABASE::Landry_Blogs TO sa
